/*
* 	Group No: 22
* 	Deepak Sharma B14107
* 	Kapardi Trivedi B14110
* 
**************************************************
**************************************************/
#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
using namespace std;
using namespace Desdemona;

/***********************************************
Matrix for providing weightage to every cell
************************************************/

int probabilityMatrix[10][10] = {
            {0,  0,  0,  0,  0,  0,  0,  0,  0,  0},
            {0, 65, -3,  6,  4,  4,  6, -3, 65,  0},
            {0, -3, -29, 3,  1,  1,  3, -29,-3,  0},
            {0,  6,  3,  5,  3,  3,  5,  3,  6,  0},
            {0,  4,  1,  3,  1,  1,  3,  1,  4,  0},
            {0,  4,  1,  3,  1,  1,  3,  1,  4,  0},
            {0,  6,  3,  5,  3,  3,  5,  3,  6,  0},
            {0, -3, -29, 3,  1,  1,  3, -29,-3,  0},
            {0, 65, -3,  6,  4,  4,  6, -3, 65,  0},
            {0,  0,  0,  0,  0,  0,  0,  0,  0,  0}
    };

/***********************************************
************************************************/

class MyBot: public OthelloPlayer
{
    public:
        MyBot( Turn turn );
        virtual Move play( const OthelloBoard& board );
    private:
};

/***********************************************
************************************************/

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}
Turn global;

/***********************************************
Evaluating Function for predicting best moves
************************************************/

int evaluationFunction(const OthelloBoard & board){
    int mobilityOfDisc = board.getValidMoves(global).size() - board.getValidMoves(other(global)).size(); 
    int discEvaluatedValue = 0;
    for (int i = 0; i < 8; ++i) {
        for (int j = 0; j < 8; ++j) {
            if (board.get(i, j) == global)
                discEvaluatedValue += probabilityMatrix[i + 1][j + 1];
            else if (board.get(i, j) == other(global))
                discEvaluatedValue -= probabilityMatrix[i + 1][j + 1];
        }
    }
    return discEvaluatedValue + mobilityOfDisc;
}

/***********************************************
Minimax Function
************************************************/

int minimaxFunction(const OthelloBoard & board, int depthOfTree,bool isMaximizingPlayer, int _CONSTANT_ALPHA, int _CONSTANT_BETA){
    if(depthOfTree == 5){
        return evaluationFunction(board);
    }
    if(isMaximizingPlayer){
        int bestValue = -10000;
        list<Move> listOfMoves = board.getValidMoves(global);
        list<Move>::iterator it;
        for(it = listOfMoves.begin(); it!=listOfMoves.end();++it){
            OthelloBoard temporaryBoard = board;
            temporaryBoard.makeMove(global, *it);
            int value = minimaxFunction(temporaryBoard, depthOfTree+1, false, _CONSTANT_ALPHA,_CONSTANT_BETA);
            bestValue = max(bestValue, value);
            _CONSTANT_ALPHA = max(_CONSTANT_ALPHA, bestValue);
            if(_CONSTANT_BETA<=_CONSTANT_ALPHA) break;
        }
        return bestValue;
    }
    else{
        int bestValue = 10000;
        list<Move> listOfMoves = board.getValidMoves(other(global));
        list<Move>::iterator it;
        for(it = listOfMoves.begin(); it!=listOfMoves.end();++it){
            OthelloBoard temporaryBoard = board;
            temporaryBoard.makeMove(other(global), *it);
            int value = minimaxFunction(temporaryBoard, depthOfTree+1, true, _CONSTANT_ALPHA,_CONSTANT_BETA);
            bestValue = min(bestValue,value);
            _CONSTANT_BETA = min(_CONSTANT_BETA, bestValue);
            if(_CONSTANT_BETA <= _CONSTANT_ALPHA) break;
        }
        return bestValue;
    }
}

/***********************************************
************************************************/

Move MyBot::play( const OthelloBoard& board )
{
    global = turn;

    list<Move> listOfMoves = board.getValidMoves( turn );
    list<Move>::iterator it;
    int _CONSTANT_ALPHA = -10000, _CONSTANT_BETA = 10000, bestValue = -10000;
    Move optimalValue = *(listOfMoves.begin());
    for(it = listOfMoves.begin();it!=listOfMoves.end();++it){
        OthelloBoard temporaryBoard = board;
        temporaryBoard.makeMove(turn, *it);
        int value = minimaxFunction(temporaryBoard, 1, false,_CONSTANT_ALPHA , _CONSTANT_BETA);
        if(value > bestValue){
            bestValue = value;
            optimalValue = *it;
        }
        _CONSTANT_ALPHA = max(_CONSTANT_ALPHA, bestValue);
        if(_CONSTANT_BETA<=_CONSTANT_ALPHA) break;
    }
    return optimalValue;
}

/***********************************************
************************************************/

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}

